from sqlalchemy import create_engine, text

DATABASE_URL = "sqlite:///t.db"
engine = create_engine(DATABASE_URL)
with engine.connect() as conn:
    user_cset_record = conn.execute(text(f"Select * from users where role_id==2"))
    l1=[]
    for i in user_cset_record:
        l1.append(i[0])
    print(l1)
    print(" successfully")

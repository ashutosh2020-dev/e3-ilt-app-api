"""changes in mdlilts

Revision ID: 6fab446b862d
Revises: f4c317048817
Create Date: 2023-05-22 21:08:10.947166

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '6fab446b862d'
down_revision = 'f4c317048817'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass

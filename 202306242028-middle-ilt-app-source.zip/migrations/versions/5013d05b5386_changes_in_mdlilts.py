"""changes in mdlilts

Revision ID: 5013d05b5386
Revises: 3c3401977d1d
Create Date: 2023-05-22 20:59:24.298031

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5013d05b5386'
down_revision = '3c3401977d1d'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass

"""changes in mdlilts

Revision ID: f4c317048817
Revises: 5013d05b5386
Create Date: 2023-05-22 21:05:54.992890

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f4c317048817'
down_revision = '5013d05b5386'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
